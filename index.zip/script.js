const dropArea = document.getElementById('drop-area');
const fileElem = document.getElementById('fileElem');
const fileList = document.getElementById('file-list');
const addMoreBtn = document.getElementById('add-more');
const downloadBtn = document.getElementById('download');

let pdfFiles = [];

async function renderFileList() {
    fileList.innerHTML = '';
    
    // Create grid container
    const gridContainer = document.createElement('div');
    gridContainer.className = 'pdf-grid';
    fileList.appendChild(gridContainer);
    
    for (let idx = 0; idx < pdfFiles.length; idx++) {
        const file = pdfFiles[idx];
        const item = document.createElement('div');
        item.className = 'grid-item';
        item.draggable = true;
        item.dataset.idx = idx;
        
        // Create preview container
        const previewContainer = document.createElement('div');
        previewContainer.className = 'preview-container';
        
        // Create file info container
        const fileInfo = document.createElement('div');
        fileInfo.className = 'file-info';
        
        const fileName = document.createElement('span');
        fileName.className = 'file-name';
        fileName.title = file.name;
        fileName.textContent = file.name.length > 15 ? file.name.substring(0, 12) + '...' : file.name;
        
        const removeBtn = document.createElement('button');
        removeBtn.className = 'remove-btn';
        removeBtn.title = 'Remove';
        removeBtn.innerHTML = '<span class="material-symbols-rounded">delete</span>';
        
        fileInfo.appendChild(fileName);
        fileInfo.appendChild(removeBtn);
        
        // Add preview and file info to item
        item.appendChild(previewContainer);
        item.appendChild(fileInfo);
        
        // Add with animation
        item.style.opacity = '0';
        item.style.transform = 'translateY(10px)';
        
        // Generate PDF preview
        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({data: arrayBuffer}).promise;
            const page = await pdf.getPage(1); // Get first page
            
            const scale = 0.2; // Smaller scale for grid view
            const viewport = page.getViewport({scale});
            
            // Create canvas for PDF preview
            const canvas = document.createElement('canvas');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            previewContainer.appendChild(canvas);
            
            const context = canvas.getContext('2d');
            await page.render({
                canvasContext: context,
                viewport: viewport
            }).promise;
        } catch (err) {
            console.error('Failed to render PDF preview:', err);
            previewContainer.innerHTML = '<div class="preview-error"><span class="material-symbols-rounded">error</span>Preview unavailable</div>';
        }
        
        // Drag events
        item.addEventListener('dragstart', (e) => {
            item.classList.add('dragging');
            e.dataTransfer.setData('text/plain', idx);
        });
        item.addEventListener('dragend', () => {
            item.classList.remove('dragging');
        });
        item.addEventListener('dragover', (e) => e.preventDefault());
        item.addEventListener('drop', (e) => {
            e.preventDefault();
            const fromIdx = +e.dataTransfer.getData('text/plain');
            const toIdx = idx;
            if (fromIdx !== toIdx) {
                const moved = pdfFiles.splice(fromIdx, 1)[0];
                pdfFiles.splice(toIdx, 0, moved);
                renderFileList();
            }
        });
        
        // Remove button
        removeBtn.onclick = () => {
            // Remove with animation
            item.style.opacity = '0';
            item.style.transform = 'scale(0.8)';
            setTimeout(() => {
                pdfFiles.splice(idx, 1);
                renderFileList();
            }, 200);
        };
        
        gridContainer.appendChild(item);
        
        // Trigger animation
        setTimeout(() => {
            item.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
        }, idx * 50); // Stagger animation
    }
    
    // Show 'Add More PDFs' only if there is at least one file
    addMoreBtn.style.display = pdfFiles.length > 0 ? '' : 'none';
}

function handleFiles(files) {
    for (const file of files) {
        if (file.type === 'application/pdf') {
            pdfFiles.push(file);
        }
    }
    renderFileList();
}

dropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropArea.classList.add('dragover');
});
dropArea.addEventListener('dragleave', () => {
    dropArea.classList.remove('dragover');
});
dropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    dropArea.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});

dropArea.addEventListener('click', () => fileElem.click());
addMoreBtn.addEventListener('click', () => fileElem.click());

fileElem.addEventListener('change', (e) => {
    handleFiles(e.target.files);
    fileElem.value = '';
});

downloadBtn.addEventListener('click', async () => {
    if (pdfFiles.length < 2) {
        alert('Please add at least two PDF files to merge.');
        return;
    }
    downloadBtn.disabled = true;
    downloadBtn.innerHTML = '<span class="material-symbols-rounded">pending</span> Merging...';
    try {
        const mergedPdf = await mergePDFs(pdfFiles);
        const blob = new Blob([mergedPdf], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'merged.pdf';
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            // Show success animation
            downloadBtn.innerHTML = '<span class="material-symbols-rounded">check_circle</span> Success!';
            setTimeout(() => {
                downloadBtn.innerHTML = '<span class="material-symbols-rounded">ios_share</span> Merge & Download';
                downloadBtn.disabled = false;
            }, 1500);
        }, 100);
    } catch (err) {
        console.error('Error merging PDFs:', err);
        alert('Failed to merge PDFs: ' + (err.message || 'Unknown error'));
        downloadBtn.innerHTML = '<span class="material-symbols-rounded">error</span> Failed';
        setTimeout(() => {
            downloadBtn.innerHTML = '<span class="material-symbols-rounded">ios_share</span> Merge & Download';
            downloadBtn.disabled = false;
        }, 1500);
    }
});

async function mergePDFs(files) {
    const { PDFDocument } = PDFLib;
    const mergedPdf = await PDFDocument.create();
    for (const file of files) {
        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await PDFDocument.load(arrayBuffer);
            const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
            copiedPages.forEach((page) => mergedPdf.addPage(page));
        } catch (err) {
            console.error('Failed to load PDF:', file.name, err);
        }
    }
    return await mergedPdf.save();
}

renderFileList();